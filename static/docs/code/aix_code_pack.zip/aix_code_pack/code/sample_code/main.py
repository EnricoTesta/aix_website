import os
from aix import load_data_in_pandas
from pickle import dump, load
from sklearn.ensemble import RandomForestClassifier
from pandas import DataFrame


def process(input_directory=None, output_directory=None):

    # Read locally (inputs folder)
    data_dict = load_data_in_pandas(input_directory)
    train_df = data_dict['d_train']
    Y = train_df['TARGET_VARIABLE'].copy()
    X = train_df.drop(columns=['TARGET_VARIABLE', 'OBS_DATE', 'Ticker']).fillna(value=0)

    # Process
    clf = RandomForestClassifier(n_estimators=10)
    trained_model = clf.fit(X, Y)

    # Write artifact
    pickle_file_name = os.path.join(output_directory, 'random_forest_model.pkl')
    with open(pickle_file_name, 'wb') as f:
        dump(trained_model, f)


def transform(input_directory=None, output_directory=None):

    # Read from input
    data_dict = load_data_in_pandas(input_directory)
    if 'd_inference' in data_dict.keys():
        transform_df = data_dict['d_inference']
    else:
        transform_df = data_dict['d_holdout']
    obs_date = transform_df['OBS_DATE'].copy()
    ticker = transform_df['Ticker'].copy()
    d = transform_df.drop(columns=['OBS_DATE', 'Ticker']).fillna(value=0)
    trained_model_filename = os.path.join(input_directory, 'random_forest_model.pkl')
    with open(trained_model_filename, 'rb') as f:
        trained_model = load(f)

    # Predict
    tmp = DataFrame(trained_model.predict_proba(d))
    tmp.rename(columns={1:'pred'}, inplace=True)
    tmp['OBS_DATE'] = obs_date
    tmp['Ticker'] = ticker
    predictions = tmp[['OBS_DATE', 'Ticker', 'pred']]

    # Write
    prediction_filename = os.path.join(output_directory, 'predictions.csv')
    DataFrame(predictions).to_csv(prediction_filename, index=False)
