import os
import unittest
from pandas import read_csv
from yaml import safe_load


# Load configuration file
with open('config.yaml', 'r') as f:
    config = safe_load(f)

HOLDOUT_PREDICTIONS_FILENAME = os.path.join(config['holdout_output_directory'], 'predictions.csv')
INFERENCE_PREDICTIONS_FILENAME = os.path.join(config['inference_output_directory'], 'predictions.csv')


class TestProcess(unittest.TestCase):

    def test_at_least_one_artifact(self):
        for (dirpath, dirnames, filenames) in os.walk(config['process_output_directory']):
            self.assertGreater(len(filenames), 0)


class TestHoldout(unittest.TestCase):
    
    def test_single_file_output(self):
        for (dirpath, dirnames, filenames) in os.walk(config['holdout_output_directory']):
            self.assertEqual(len(filenames), 1)
            self.assertEqual(len(dirnames), 0)

    def test_prediction_file_name(self):
        for (dirpath, dirnames, filenames) in os.walk(config['holdout_output_directory']):
            self.assertEqual(filenames[0], 'predictions.csv')

    def test_column_number(self):
        mock_predictions = read_csv(HOLDOUT_PREDICTIONS_FILENAME)
        mock_predictions_columns = mock_predictions.columns
        self.assertEqual(len(mock_predictions_columns), 3)

    def test_first_column_name(self):
        mock_predictions = read_csv(HOLDOUT_PREDICTIONS_FILENAME)
        mock_predictions_columns = mock_predictions.columns
        self.assertEqual(mock_predictions_columns[0], 'OBS_DATE')

    def test_second_column_name(self):
        mock_predictions = read_csv(HOLDOUT_PREDICTIONS_FILENAME)
        mock_predictions_columns = mock_predictions.columns
        self.assertEqual(mock_predictions_columns[1], 'Ticker')

    def test_third_column_name(self):
        mock_predictions = read_csv(HOLDOUT_PREDICTIONS_FILENAME)
        mock_predictions_columns = mock_predictions.columns
        self.assertEqual(mock_predictions_columns[2], 'pred')

    def test_third_not_null(self):
        mock_predictions = read_csv(HOLDOUT_PREDICTIONS_FILENAME)
        self.assertEqual(mock_predictions['pred'].isna().sum(), 0)


class TestInference(unittest.TestCase):

    def test_single_file_output(self):
        for (dirpath, dirnames, filenames) in os.walk(config['inference_output_directory']):
            self.assertEqual(len(filenames), 1)
            self.assertEqual(len(dirnames), 0)

    def test_prediction_file_name(self):
        for (dirpath, dirnames, filenames) in os.walk(config['inference_output_directory']):
            self.assertEqual(filenames[0], 'predictions.csv')

    def test_column_number(self):
        mock_predictions = read_csv(INFERENCE_PREDICTIONS_FILENAME)
        mock_predictions_columns = mock_predictions.columns
        self.assertEqual(len(mock_predictions_columns), 3)

    def test_first_column_name(self):
        mock_predictions = read_csv(INFERENCE_PREDICTIONS_FILENAME)
        mock_predictions_columns = mock_predictions.columns
        self.assertEqual(mock_predictions_columns[0], 'OBS_DATE')

    def test_second_column_name(self):
        mock_predictions = read_csv(INFERENCE_PREDICTIONS_FILENAME)
        mock_predictions_columns = mock_predictions.columns
        self.assertEqual(mock_predictions_columns[1], 'Ticker')

    def test_third_column_name(self):
        mock_predictions = read_csv(INFERENCE_PREDICTIONS_FILENAME)
        mock_predictions_columns = mock_predictions.columns
        self.assertEqual(mock_predictions_columns[2], 'pred')

    def test_third_not_null(self):
        mock_predictions = read_csv(INFERENCE_PREDICTIONS_FILENAME)
        self.assertEqual(mock_predictions['pred'].isna().sum(), 0)


if __name__ == 'main':
    unittest.main()
