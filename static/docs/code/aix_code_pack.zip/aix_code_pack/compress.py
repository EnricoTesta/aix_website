import os
from logging import getLogger
from platform import system
from tempfile import TemporaryDirectory
from zipfile import ZipFile
from yaml import safe_load

zip_logger = getLogger('zip_logger')

if system() == 'Windows':
    FOLDER_DELIMITER = '\\'
else:
    FOLDER_DELIMITER = '/'

# Load configuration file
with open('config.yaml', 'r') as f:
    config = safe_load(f)

with TemporaryDirectory() as tmpdir:
    with ZipFile(config['zip_file_full_name'], 'w') as f:
        target_directory = os.path.join(os.getcwd(), 'code')
        zip_logger.info(f"Zip file will be created from directory: {target_directory}")
        for folderName, subfolders, filenames in os.walk(target_directory):
            zip_logger.info(
                f"Walking. Folder name: {folderName}, subfolders: {subfolders}, filenames: {filenames}")
            if not folderName.endswith('__pycache__'):
                for filename in filenames:
                    if not filename.startswith('.'):
                        filepath = os.path.join(folderName, filename)
                        if filename == 'requirements.txt':
                            f.write(filepath, os.path.basename(filepath))
                        else:
                            f.write(filepath, os.path.join(folderName.split(FOLDER_DELIMITER)[-1],
                                                           os.path.basename(filepath)))
