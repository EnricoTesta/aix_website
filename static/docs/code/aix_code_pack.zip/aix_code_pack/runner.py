import os
import sys
from shutil import rmtree, copy
from yaml import safe_load
from importlib import import_module
from logging import basicConfig, getLogger, INFO

basicConfig()
logger = getLogger("aix-code-runner")
logger.setLevel(INFO)

logger.info("Loading configuration file...")
# Load configuration file
with open('config.yaml', 'r') as f:
    config = safe_load(f)

logger.info("Setting up directories...")
# Setup work directories
try:
    rmtree(config['work_directory'])
except:
    pass
os.mkdir(config['work_directory'])
os.mkdir(config['process_output_directory'])
os.mkdir(config['inference_output_directory'])
os.mkdir(config['inference_input_directory'])
os.mkdir(os.path.join(config['inference_input_directory'], 'data'))
os.mkdir(config['holdout_output_directory'])
os.mkdir(config['holdout_input_directory'])
os.mkdir(os.path.join(config['holdout_input_directory'], 'data'))

logger.info("Importing custom module...")
# Import function callables
sys.path.append(os.path.join(os.getcwd(), "code", config['package_name']))
custom_module = import_module("main", package=config['package_name'])
fn_process = getattr(custom_module, "process")
fn_transform = getattr(custom_module, "transform")

logger.info("Running process...")
# Run process
fn_process(input_directory="data/train", output_directory=config['process_output_directory'])

logger.info("Setting up holdout directory...")
# Setup holdout input directory
for (dirpath, dirnames, filenames) in os.walk("data/holdout"):  # copy data
    for filename in filenames:
        copy(os.path.join(dirpath, filename), os.path.join(config['holdout_input_directory'], 'data', filename))

for (dirpath, dirnames, filenames) in os.walk(config['process_output_directory']):  # copy artifacts
    for filename in filenames:
        copy(os.path.join(dirpath, filename), os.path.join(config['holdout_input_directory'], filename))

logger.info("Running transform on holdout set...")
# Run holdout
fn_transform(input_directory=config['holdout_input_directory'], output_directory=config['holdout_output_directory'])

logger.info("Setting up inference directory...")
# Setup inference input directory
for (dirpath, dirnames, filenames) in os.walk("data/inference"):  # copy data
    for filename in filenames:
        copy(os.path.join(dirpath, filename), os.path.join(config['inference_input_directory'], 'data', filename))

for (dirpath, dirnames, filenames) in os.walk(config['process_output_directory']):  # copy artifacts
    for filename in filenames:
        copy(os.path.join(dirpath, filename), os.path.join(config['inference_input_directory'], filename))

logger.info("Running transform on inference set...")
# Run inference
fn_transform(input_directory=config['inference_input_directory'], output_directory=config['inference_output_directory'])
